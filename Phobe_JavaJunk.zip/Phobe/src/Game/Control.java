package Game;
public enum Control {
	UP,DOWN,LEFT,RIGHT,OIL,GLUE
}